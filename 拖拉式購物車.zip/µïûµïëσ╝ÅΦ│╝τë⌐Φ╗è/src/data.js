let shopItemsData = [{
    id: "l01",
    name: "JavaScript實作",
    price: 900,
    desc: "暢銷回饋版，基礎語法、物件、原型、類別等實務運用！",
    img: "images/01.jpeg"
}, {
    id: "l02",
    name: "JavaScript技術手冊",
    price: 850,
    desc: "ES6到ES11基礎語法、物件、原型、類別等實務運用。",
    img: "images/02.jpeg"
}, {
    id: "l03",
    name: "JavaScript大全 第七版",
    price: 1200,
    desc: "精通全世界最多人使用的程式語言，JavaScript！",
    img: "images/03.jpeg"
}, {
    id: "l04",
    name: "精通JavaScript 第三版",
    price: 1000,
    desc: "導入現代程式設計原則，詳盡介紹ES6到ES11的各種基礎語法！",
    img: "images/04.jpeg"
}];